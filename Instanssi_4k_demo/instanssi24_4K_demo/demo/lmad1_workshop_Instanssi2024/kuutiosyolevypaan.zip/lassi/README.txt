Cube eats diskhead 4K
======================
Small demo made at instanssi 2024 4k workshop.

Author:     LKKarjalainen
            lassikarjalainen0@gmail.com

Techniques: lmad1 workshop code (Javascript, WebGL, SoundBox, Closure
            Compiler, Pnginator)

This production uses the SoundBox synthesizer tracker by Marcus
Geelnard: (http://sb.bitsnbites.eu/).
